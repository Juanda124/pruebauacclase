package com.example.skinscs2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SkinAdapter extends RecyclerView.Adapter<SkinAdapter.SkinViewHolder> {

    private final List<Skin> lista;

    public SkinAdapter(List<Skin> lista) {
        this.lista = lista;
    }

    @NonNull
    @Override
    public SkinViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_skin, parent, false);
        return new SkinViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SkinViewHolder holder, int position) {
        Skin skin = lista.get(position);
        holder.imagen.setImageResource(skin.getImagen());
        holder.nombre.setText(skin.getNombre());
        holder.precio.setText(skin.getPrecio());
        holder.descripcion.setText(skin.getDescripcion());
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    static class SkinViewHolder extends RecyclerView.ViewHolder {
        ImageView imagen;
        TextView nombre;
        TextView precio;
        TextView descripcion;

        SkinViewHolder(@NonNull View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imgSkin);
            nombre = itemView.findViewById(R.id.txtNombre);
            precio = itemView.findViewById(R.id.txtPrecio);
            descripcion = itemView.findViewById(R.id.txtDescripcion);
        }
    }
}
