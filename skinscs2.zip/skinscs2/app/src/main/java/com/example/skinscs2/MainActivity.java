package com.example.skinscs2;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        List<Skin> lista = new ArrayList<>();
        lista.add(new Skin("Counter-Strike 2", "Juego gratis",
                "El juego es gratuito, pero sus skins se compran y se venden en el mercado de Steam con precios reales.",
                R.drawable.skin1));
        lista.add(new Skin("AK-47 Hydroponic", "Más de 1.000 USD",
                "Skin muy rara de diseño floral. Su precio sube cuando está casi nueva y tiene pocos desgastes.",
                R.drawable.skin2));
        lista.add(new Skin("Guantes Moto", "Hasta más de 1.000 USD",
                "Los guantes no se consiguen en partidas, solo abriendo cajas o comprándolos. Los mejores diseños son escasos.",
                R.drawable.skin3));
        lista.add(new Skin("Agente con M4A1", "Desde 5 USD",
                "Los agentes son personajes decorativos. Usarlos con armas de colores no cambia el daño, solo el estilo.",
                R.drawable.skin4));
        lista.add(new Skin("Cuchillo M9 y AK-47", "Miles de USD",
                "Los cuchillos son los objetos más caros. Se valoran por su patrón único, su rareza y el desgaste.",
                R.drawable.skin5));
        lista.add(new Skin("Cajas de armamento", "Caja + llave 2,50 USD",
                "Se abren con una llave y la probabilidad de sacar un cuchillo o guantes es muy baja, por eso valen tanto.",
                R.drawable.skin6));

        RecyclerView recyclerView = findViewById(R.id.recyclerSkins);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new SkinAdapter(lista));
    }
}
