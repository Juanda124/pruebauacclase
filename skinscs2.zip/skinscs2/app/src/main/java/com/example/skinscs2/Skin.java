package com.example.skinscs2;

public class Skin {
    private final String nombre;
    private final String precio;
    private final String descripcion;
    private final int imagen;

    public Skin(String nombre, String precio, String descripcion, int imagen) {
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrecio() {
        return precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getImagen() {
        return imagen;
    }
}
